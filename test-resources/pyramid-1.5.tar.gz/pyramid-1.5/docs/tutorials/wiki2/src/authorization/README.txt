tutorial README
==================

Getting Started
---------------

- cd <directory containing this file>

- $VENV/bin/python setup.py develop

- $VENV/bin/initialize_tutorial_db development.ini

- $VENV/bin/pserve development.ini

