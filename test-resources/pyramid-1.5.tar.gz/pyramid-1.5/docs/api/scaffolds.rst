.. _scaffolds_module:

:mod:`pyramid.scaffolds`
------------------------

.. automodule:: pyramid.scaffolds

  .. autoclass:: pyramid.scaffolds.Template
     :members:

  .. autoclass:: pyramid.scaffolds.PyramidTemplate
     :members:

