===============
``util`` module
===============

.. automodule:: whoosh.util
    :members:

